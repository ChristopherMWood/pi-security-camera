hello_videocube
===============

Sample for Raspberry Pi that uses egl_render to display video on an animated cube.